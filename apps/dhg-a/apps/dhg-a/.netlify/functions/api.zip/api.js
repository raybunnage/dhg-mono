exports.handler = async function(event, context) {
  console.log('Function running in:', process.env.CONTEXT);
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: 'API is working!',
      environment: process.env.CONTEXT,
      time: new Date().toISOString()
    })
  };
}
