exports.handler = async function(event, context) {
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({
      environment: {
        context: process.env.CONTEXT,
        nodeEnv: process.env.NODE_ENV,
        appName: process.env.VITE_APP_NAME,
        features: process.env.VITE_FEATURE_FLAGS
      }
    })
  };
}
